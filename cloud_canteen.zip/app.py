import os
import uuid

from dotenv import load_dotenv

load_dotenv()

from functools import wraps
from decimal import Decimal
from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import pooling
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")

dbconfig = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "root"),
    "database": os.getenv("DB_NAME", "canteen_db"),
}
pool = pooling.MySQLConnectionPool(pool_name="canteen_pool", pool_size=5, **dbconfig)

def get_db():
    return pool.get_connection()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        student_id = request.form["student_id"].strip()
        password = request.form["password"]

        if not name or not email or not student_id or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT id FROM users WHERE email=%s OR student_id=%s", (email, student_id))
        if cur.fetchone():
            cur.close(); conn.close()
            flash("Email or student ID already exists.", "danger")
            return redirect(url_for("register"))

        cur.execute(
            "INSERT INTO users(name,email,student_id,password_hash,role) VALUES(%s,%s,%s,%s,'student')",
            (name, email, student_id, generate_password_hash(password))
        )
        conn.commit()
        cur.close(); conn.close()
        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close(); conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            return redirect(url_for("admin_dashboard" if user["role"] == "admin" else "menu"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully.", "success")
    return redirect(url_for("index"))

@app.route("/menu")
@login_required
def menu():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM food_items WHERE available=1 ORDER BY category,name")
    foods = cur.fetchall()
    cur.close(); conn.close()
    return render_template("menu.html", foods=foods)

@app.route("/cart")
@login_required
def cart():
    cart_data = session.get("cart", {})
    ids = [int(k) for k in cart_data.keys()]
    foods = []
    total = Decimal("0.00")
    if ids:
        conn = get_db()
        cur = conn.cursor(dictionary=True)
        placeholders = ",".join(["%s"] * len(ids))
        cur.execute(f"SELECT * FROM food_items WHERE id IN ({placeholders}) AND available=1", ids)
        foods = cur.fetchall()
        cur.close(); conn.close()
        for food in foods:
            qty = int(cart_data.get(str(food["id"]), 0))
            food["quantity"] = qty
            food["subtotal"] = Decimal(str(food["price"])) * qty
            total += food["subtotal"]
    return render_template("cart.html", foods=foods, total=total)

@app.route("/cart/add/<int:food_id>", methods=["POST"])
@login_required
def add_to_cart(food_id):
    cart_data = session.get("cart", {})
    key = str(food_id)
    cart_data[key] = int(cart_data.get(key, 0)) + 1
    session["cart"] = cart_data
    flash("Item added to cart.", "success")
    return redirect(request.referrer or url_for("menu"))

@app.route("/cart/remove/<int:food_id>", methods=["POST"])
@login_required
def remove_from_cart(food_id):
    cart_data = session.get("cart", {})
    key = str(food_id)
    cart_data.pop(key, None)
    session["cart"] = cart_data
    return redirect(url_for("cart"))

@app.route("/place-order", methods=["POST"])
@login_required
def place_order():
    cart_data = session.get("cart", {})
    if not cart_data:
        flash("Your cart is empty.", "warning")
        return redirect(url_for("menu"))

    ids = [int(k) for k in cart_data.keys()]
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    placeholders = ",".join(["%s"] * len(ids))
    cur.execute(f"SELECT * FROM food_items WHERE id IN ({placeholders}) AND available=1", ids)
    foods = cur.fetchall()

    total = Decimal("0.00")
    for food in foods:
        total += Decimal(str(food["price"])) * int(cart_data[str(food["id"])])

    order_code = "ORD-" + uuid.uuid4().hex[:8].upper()
    cur.execute(
        "INSERT INTO orders(order_code,user_id,total_amount,status) VALUES(%s,%s,%s,'Placed')",
        (order_code, session["user_id"], total)
    )
    order_id = cur.lastrowid

    for food in foods:
        qty = int(cart_data[str(food["id"])])
        cur.execute(
            "INSERT INTO order_items(order_id,food_id,quantity,unit_price) VALUES(%s,%s,%s,%s)",
            (order_id, food["id"], qty, food["price"])
        )
    conn.commit()
    cur.close(); conn.close()

    session["cart"] = {}
    return redirect(url_for("order_success", order_code=order_code))

@app.route("/order-success/<order_code>")
@login_required
def order_success(order_code):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT o.*, u.name AS student_name
        FROM orders o JOIN users u ON o.user_id=u.id
        WHERE o.order_code=%s AND o.user_id=%s
    """, (order_code, session["user_id"]))
    order = cur.fetchone()
    cur.close(); conn.close()
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("orders"))
    return render_template("order_success.html", order=order)

@app.route("/orders")
@login_required
def orders():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT * FROM orders WHERE user_id=%s ORDER BY created_at DESC
    """, (session["user_id"],))
    rows = cur.fetchall()
    cur.close(); conn.close()
    return render_template("orders.html", orders=rows)

@app.route("/track/<order_code>")
@login_required
def track_order(order_code):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT * FROM orders WHERE order_code=%s AND user_id=%s
    """, (order_code, session["user_id"]))
    order = cur.fetchone()
    cur.close(); conn.close()
    if not order:
        flash("Order not found.", "danger")
        return redirect(url_for("orders"))
    return render_template("track_order.html", order=order)

@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE()")
    today_orders = cur.fetchone()["c"]
    cur.execute("SELECT COALESCE(SUM(total_amount),0) AS s FROM orders WHERE DATE(created_at)=CURDATE() AND status='Completed'")
    today_sales = cur.fetchone()["s"]
    cur.execute("SELECT status, COUNT(*) AS c FROM orders WHERE DATE(created_at)=CURDATE() GROUP BY status")
    counts = {r["status"]: r["c"] for r in cur.fetchall()}
    cur.close(); conn.close()
    return render_template("admin/dashboard.html",
                           today_orders=today_orders, today_sales=today_sales, counts=counts)

@app.route("/admin/orders")
@admin_required
def admin_orders():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT o.*, u.name AS student_name, u.student_id
        FROM orders o JOIN users u ON o.user_id=u.id
        ORDER BY o.created_at DESC
    """)
    rows = cur.fetchall()
    cur.close(); conn.close()
    return render_template("admin/orders.html", orders=rows)

@app.route("/admin/order/<int:order_id>/status", methods=["POST"])
@admin_required
def update_status(order_id):
    status = request.form["status"]
    allowed = {"Placed", "Preparing", "Ready", "Completed", "Cancelled"}
    if status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("admin_orders"))
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE orders SET status=%s WHERE id=%s", (status, order_id))
    conn.commit()
    cur.close(); conn.close()
    flash("Order status updated.", "success")
    return redirect(url_for("admin_orders"))

@app.route("/admin/food")
@admin_required
def admin_food():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM food_items ORDER BY category,name")
    foods = cur.fetchall()
    cur.close(); conn.close()
    return render_template("admin/food.html", foods=foods)

@app.route("/admin/food/add", methods=["POST"])
@admin_required
def add_food():
    name = request.form["name"].strip()
    category = request.form["category"].strip()
    price = request.form["price"]
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT INTO food_items(name,category,price,available) VALUES(%s,%s,%s,1)",
                (name, category, price))
    conn.commit()
    cur.close(); conn.close()
    flash("Food item added.", "success")
    return redirect(url_for("admin_food"))

@app.route("/admin/food/<int:food_id>/toggle", methods=["POST"])
@admin_required
def toggle_food(food_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE food_items SET available = IF(available=1,0,1) WHERE id=%s", (food_id,))
    conn.commit()
    cur.close(); conn.close()
    return redirect(url_for("admin_food"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
