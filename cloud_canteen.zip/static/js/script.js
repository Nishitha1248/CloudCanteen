console.log("CloudCanteen loaded");
